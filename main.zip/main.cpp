/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world."
programa que pide edad del usuario y determina si es mayor de edad o menor de edad".

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int edad;
    
    cout<<"ingresar tu edad"<<endl;
    cin>>edad;
    if(edad>=18)
    {cout<<"Eres mayor de edad";
    }
    else{cout<<"Eres menor de edad";
    }



    return 0;
}